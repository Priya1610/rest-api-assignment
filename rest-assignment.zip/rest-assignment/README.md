# Read Me First

The project is build using Eclipse Version: 2021-03 (4.19.0), JDK 8 and Maven 3.6.3J
The app has two access groups
1) Admin user has read and write privilege , the password is adminn
2) User user has only write privilege, the password is user.

Once login , swagger and h2 console path is as below

http://localhost:8085/swagger-ui.html
http://localhost:8085/h2-console/

Endpoints:

 6 endpoints have been exposed to perform various operation on Company and Owner objects.
 
 1) create new Company : It can have list of owners. curl is below
 
 curl -X POST --header 'Content-Type: application/json' --header 'Accept: */*' -d '{ \ 
   "companyName": "SG", \ 
   "country": "India", \ 
   "id": 1, \ 
   "ownerList": [ \ 
     { \ 
       "companyId": 1, \ 
       "id": 1, \ 
       "name": "Owner1", \ 
       "ssn": "ADDDDDD" \ 
     }, \ 
 { \ 
       "companyId": 1, \ 
       "id": 2, \ 
       "name": "Owner2", \ 
       "ssn": "FFFFFF" \ 
     } \ 
   ], \ 
   "phoneNumber": "1234567" \ 
 }' 'http://localhost:8085/Api-assignment/newCompany'
 
 2) List of companies : curl -X GET --header 'Accept: application/json' 'http://localhost:8085/Api-assignment/companyList'
 
 3) Details about company : curl -X GET --header 'Accept: application/json' 'http://localhost:8085/Api-assignment/companyDetails?companyId=1'
 
 4) Update a company : curl -X POST --header 'Content-Type: application/json' --header 'Accept: */*' 'http://localhost:8085/Api-assignment/updateCompany?companyId=1&country=France'
 
 5) Add owner of a company : curl -X POST --header 'Content-Type: application/json' --header 'Accept: */*' -d '{ \ 
   "companyId": 1, \ 
   "id": 4, \ 
   "name": "Owner4", \ 
   "ssn": "DDDDDD" \ 
 }' 'http://localhost:8085/Api-assignment/addOwner?comapny_id=1'
 
 6) Validate SSN : The format for this API call is AAA-GG-SSSS 
 
 Examples of valid SSN : 856-45-6789
 Examples of Invalid SSN : 856-455-6789, 000-455-6789
 
 Curl command is : curl -X POST --header 'Content-Type: application/json' --header 'Accept: text/plain' 'http://localhost:8085/Api-assignment/validateSsn?ssn=000-455-6789'
 
 Note : During DB write , the SSN and phone numbers are String , without any validation.

# Getting Deployed using Docker

The Dockerfile is added to the project.Run the below commands from the project path

to check the docker version installed : docker -v

to build the image from file : docker build -f Dockerfile -t docker-rest-api .

to check the build image : docker images

to push the code/start the app : docker run -p 8085:8085 docker-rest-api

Once started , the app is available at localhost:8085/login

P.S : The laptop used to create the assignment didn't have the Docker Deskop client installed due to security issues , so the build and run commands are shared from my existing official project. I couldnt test the build/deploy using Docker.




