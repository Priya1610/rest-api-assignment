package com.danske.api.restassignment.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.danske.api.restassignment.beans.Company;
import com.danske.api.restassignment.beans.Owner;
import com.danske.api.restassignment.exception.CompanyNotFound;
import com.danske.api.restassignment.service.RestApiService;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/Api-assignment")
public class RestApiController {
	
	@Autowired
	RestApiService service;
		
	
	@RequestMapping(value = "/newCompany", method = RequestMethod.POST)
	@ApiOperation("Create a new Company object")
	   public void createCompany(@RequestBody Company company) {
	      service.createNewCompany(company);
	 }
	
	@RequestMapping(value = "/companyList", method = RequestMethod.GET)
	@ApiOperation("Get the list of all companies")
	   public List<Company> getCompanyList() {
			return service.getCompanyList();
	 }
	
	@RequestMapping(value = "/companyDetails", method = RequestMethod.GET)
	@ApiOperation("Get details about a specify company")
	   public Company getCompanyDetails(@RequestParam int companyId) {
	     return service.getCompanyDetails(companyId);
	 }

	@RequestMapping(value = "/updateCompany", method = RequestMethod.POST)
	@ApiOperation("Update country column in the company")
	   public void updateCompany(@RequestParam int companyId, @RequestParam String country) {
	     service.updateCompany(companyId, country);
	 }
	
	@RequestMapping(value = "/addOwner", method = RequestMethod.POST)
	@ApiOperation("Add owner of a company")
	   public void addOwner(@RequestBody Owner owner, @RequestParam int comapny_id) {
	     service.addOwner(owner, comapny_id);
	 }
	
	@RequestMapping(value = "/validateSsn", method = RequestMethod.GET)
	@ApiOperation("Validate the SSN")
	   public String validateSSN(@RequestParam String ssn) {
	     return service.validateSSN(ssn);
	 }
	
}
