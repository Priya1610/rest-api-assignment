package com.danske.api.restassignment.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Repository;
import com.danske.api.restassignment.beans.Company;
import com.danske.api.restassignment.beans.Owner;
import com.danske.api.restassignment.beans.User;
import com.danske.api.restassignment.exception.CompanyNotFound;
import com.danske.api.restassignment.exception.ExceptionResponse;
import com.danske.api.restassignment.utils.Utility;


@Repository
public class RestApiRepository {
	
	@Autowired
	JdbcTemplate jdbcTemplate;
		
	@PersistenceContext
    private EntityManager entityManager;
	
	@Autowired
	User user;
	
	@Transactional
	public void createNewCompany(Company company) {
	    entityManager.createNativeQuery("INSERT INTO Company (company_id,company_name, country, phone_number) VALUES (?,?,?,?)")
	  	      .setParameter(1, company.getId())
	      .setParameter(2, company.getCompanyName())
	      .setParameter(3, company.getCountry())
	      .setParameter(4, company.getPhoneNumber())
	      .executeUpdate();
	    for(Owner own : company.getOwnerList()) {
	    	entityManager.createNativeQuery("INSERT INTO Owner (owner_id, name, ssn, company_id) VALUES (?,?,?,?)")
	    	.setParameter(1, own.getId())
	  	    .setParameter(2, own.getName())
	      .setParameter(3, own.getSsn())
	      .setParameter(4, own.getCompanyId())
	 	  .executeUpdate();
	    }
	}


	@Transactional
	public List<Company> getCompanyList() {
		List<Company> cmpList = new ArrayList<>();
		List<Owner> ownerList = new ArrayList<>();
		Company company = new Company();
		String sql ="select * from company c, owner o where c.company_id = o.company_id";
		jdbcTemplate.query(sql,new RowCallbackHandler() {
			@Override
			public void processRow(ResultSet rs) throws SQLException {
				Owner owner = new Owner();
				company.setId(rs.getInt("company_id"));
				company.setCompanyName(rs.getString("company_name"));
				company.setCountry(rs.getString("country"));
				company.setPhoneNumber(rs.getString("phone_number"));
				owner.setId(rs.getInt("owner_id"));
				owner.setName(rs.getString("name"));
				owner.setCompanyId(rs.getInt("company_id"));
				if(user.getName().contains("Admin")) {
					owner.setSsn(rs.getString("ssn"));
				}
				ownerList.add(owner);
				
			}
		});
		company.setOwnerList(ownerList);
		cmpList.add(company);
		return cmpList;
				
	}

	@SuppressWarnings("deprecation")
	@Transactional
	public Company getCompanyDetails(int companyId) {
		List<Owner> ownerList = new ArrayList<>();
		Company company = new Company();
		String query = "select * from company c inner join owner o on c.company_id = o.company_id and c.company_id =?";
		jdbcTemplate.query(query, new Object[] {companyId},  new RowCallbackHandler() {
			@Override
			public void processRow(ResultSet rs) throws SQLException {
				Owner owner = new Owner();
				company.setId(rs.getInt("company_id"));
				company.setCompanyName(rs.getString("company_name"));
				company.setCountry(rs.getString("country"));
				company.setPhoneNumber(rs.getString("phone_number"));
				owner.setId(rs.getInt("owner_id"));
				owner.setName(rs.getString("name"));
				owner.setCompanyId(rs.getInt("company_id"));
				if(user.getName().contains("Admin")) {
					owner.setSsn(rs.getString("ssn"));
				}
				ownerList.add(owner);
			}
		});
		company.setOwnerList(ownerList);
		return company;
	}

	@Transactional
	public void updateCompany(int companyId, String country) {
		int count = entityManager.createNativeQuery("update company set country=? where company_id=?")
	      		.setParameter(1, country)
	      		.setParameter(2, companyId)
	      		.executeUpdate();
		if(count == 0) {
			throw new ExceptionResponse("Company details not exist");
		}
			
	}

	@Transactional
	public void addOwner(Owner owner, int companyId) {
	int row =checkCompanyExists(companyId);
	if(row > 0) {
		entityManager.createNativeQuery("INSERT INTO Owner (owner_id, name, ssn, company_id) VALUES (?,?,?,?)")
    	.setParameter(1, owner.getId())
  	    .setParameter(2, owner.getName())
      .setParameter(3, owner.getSsn())
      .setParameter(4, owner.getCompanyId())
 	  .executeUpdate();
	}else
		throw new CompanyNotFound("Company id doesn't exist");
		 	
	}

	private int checkCompanyExists(int companyId) {
		String sqlquery="select count(*) from company where company_id=?";
		@SuppressWarnings("deprecation")
		int rowCnt = jdbcTemplate.queryForObject(
                sqlquery, new Object[] { companyId}, Integer.class);
			return rowCnt;
		}


	public String validateSSN(String ssn) {
		Pattern pattern = Pattern.compile(Utility.SSN_REGEX);
		Matcher matcher = pattern.matcher(ssn);
		if(matcher.matches()) {
			return Utility.VALID_SSN;
		}else {
			return Utility.INVALID_SSN;
		}
		
		
	}

}
