package com.danske.api.restassignment.dao;

import org.springframework.data.repository.CrudRepository;

import com.danske.api.restassignment.beans.Role;

public interface RoleRepository extends CrudRepository<Role, Long>{

	Role findByName(String userName);

}
