package com.danske.api.restassignment.utils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Utility {
	
	public static final String VALID_SSN="Valid SSN";
	public static final String INVALID_SSN="Invalid SSN";
	public static final String SSN_REGEX="^(?!000|666)[0-8][0-9]{2}-(?!00)[0-9]{2}-(?!0000)[0-9]{4}$";
	
	public String maskSSN(String ssn) {
		Pattern p = Pattern.compile("^(\\d{3}[- ]?\\d{2}[- ]?)(\\d{4})$");
	    Matcher m = p.matcher(ssn);
	    if (m.matches()) {
	        System.out.println("XXX-XX-" + m.group(2));
	    }
		return "XXX-XX-" + m.group(2);
	}
	
}
