package com.danske.api.restassignment.exception;

import lombok.Data;

public class ExceptionResponse extends RuntimeException{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String errorCode;
	private String errorMesage;
	
	
	
	
	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMesage() {
		return errorMesage;
	}

	public void setErrorMesage(String errorMesage) {
		this.errorMesage = errorMesage;
	}

	public ExceptionResponse() {
		
	}
	
	public ExceptionResponse(String errMsg) {
		super(errMsg);
	}
}
