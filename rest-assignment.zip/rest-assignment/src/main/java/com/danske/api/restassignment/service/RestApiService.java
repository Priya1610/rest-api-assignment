package com.danske.api.restassignment.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.danske.api.restassignment.beans.Company;
import com.danske.api.restassignment.beans.Owner;
import com.danske.api.restassignment.dao.RestApiRepository;
import com.danske.api.restassignment.exception.CompanyNotFound;

@Service
public class RestApiService {
	
	@Autowired
	RestApiRepository repository;

	public void createNewCompany(Company comp) {
		
		repository.createNewCompany(comp);
		
	}

	public List<Company> getCompanyList() {
		
		return repository.getCompanyList();
		
	}

	public Company getCompanyDetails(int companyId) {
		
		return repository.getCompanyDetails(companyId);
	}

	public void updateCompany(int companyId, String country) {
		
		repository.updateCompany(companyId, country);
	}

	public void addOwner(Owner owner, int comapny_id) throws CompanyNotFound {
		
		repository.addOwner(owner, comapny_id);
		
	}

	public String validateSSN(String ssn) {
		
		return repository.validateSSN(ssn);
		
	}

}
