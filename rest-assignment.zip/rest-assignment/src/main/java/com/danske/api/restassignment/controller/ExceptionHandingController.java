package com.danske.api.restassignment.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;

import com.danske.api.restassignment.exception.CompanyNotFound;
import com.danske.api.restassignment.exception.ExceptionResponse;

@RestController
public class ExceptionHandingController {
	
	@ExceptionHandler(CompanyNotFound.class)
	public ResponseEntity<ExceptionResponse> companyNotFound(CompanyNotFound ie){
		ExceptionResponse resp = new ExceptionResponse();
		resp.setErrorCode(String.valueOf(HttpStatus.NO_CONTENT.value()));
		resp.setErrorMesage(ie.getMessage());
		return new ResponseEntity<ExceptionResponse>(resp , HttpStatus.OK);
	}

}
