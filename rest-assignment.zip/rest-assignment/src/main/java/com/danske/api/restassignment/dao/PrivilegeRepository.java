package com.danske.api.restassignment.dao;

import org.springframework.data.repository.CrudRepository;

import com.danske.api.restassignment.beans.Privilege;

public interface PrivilegeRepository extends CrudRepository<Privilege, Long>{

	Privilege findByName(String privilege);

}
