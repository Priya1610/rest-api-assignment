package com.danske.api.restassignment.beans;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.persistence.*;

@Entity
@Table(name = "company")
public class Company {
	
	public Company() {
		
	}
	
	public Company(int id, String companyName, String country, String phoneNo) {
		this.id=id;
		this.companyName=companyName;
		this.country=country;
		this.phoneNumber=phoneNo;
	}

	@Id
	@Column(name = "company_id")
	private int id;
	
	private String companyName;
	private String country;
	private String phoneNumber;
	
	@OneToMany(targetEntity=Owner.class)
	@JoinTable(
            name = "company_owner",
            joinColumns = @JoinColumn(name = "company_id"),
            inverseJoinColumns = @JoinColumn(name = "owner_id")
            )
	private List<Owner> ownerList;
	
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public List<Owner> getOwnerList() {
		return ownerList;
	}
	public void setOwnerList(List<Owner> ownerList) {
		this.ownerList = ownerList;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	
}
