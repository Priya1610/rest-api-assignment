
 package com.danske.api.restassignment.utils;
 
 import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
 
public class SecurePassword {
 

public String encode(String rawPassword) {
	BCryptPasswordEncoder encoder = new BCryptPasswordEncoder(); 
	return encoder.encode(rawPassword);
} }
 